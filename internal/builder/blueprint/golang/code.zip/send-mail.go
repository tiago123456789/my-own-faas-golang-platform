package lambda

import (
	"fmt"

	"github.com/gofiber/fiber/v2"
	"go.uber.org/zap"
	gomail "gopkg.in/mail.v2"
)

func Handler(c *fiber.Ctx, logger *zap.Logger) error {
	message := gomail.NewMessage()

	// Set email headers
	message.SetHeader("From", "youremail@email.com")
	message.SetHeader("To", "recipient1@email.com")
	message.SetHeader("Subject", "Hello from the Mailtrap team")

	// Set email body
	message.SetBody("text/plain", "This is the Test Body")

	// Set up the SMTP dialer
	dialer := gomail.NewDialer("sandbox.smtp.mailtrap.io", 587, "2501af0434d3a0", "586c3facdb7074")

	// Send the email
	if err := dialer.DialAndSend(message); err != nil {
		fmt.Println("Error:", err)
		return c.Status(500).JSON(fiber.Map{
			"message": err.Error(),
		})
	} else {
		return c.Status(200).JSON(fiber.Map{
			"message": "Email sent successfully!",
		})
	}
}
